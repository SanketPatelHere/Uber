import 'package:flutter/material.dart';

class AppConstant{
  static String appMainName = "Ecomm Admin";
  static String appMainNameAdmin = "Ecomm Admin App";
  static String appPoweredBy = "Powered By SR";
  static const appMainColor = Color(0xffbf1b08);
  static const appSecondaryColor = Color(0xff981206);
  static const appTextColor = Color(0xfffbf5f4);
  static const appTextColor2 = Color(0xff000000);
  static const appStatusBarColor = Color(0xfffbf5f4);
}