package com.example.aaa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
